// https://docs.oracle.com/javase/tutorial/essential/io/file.html#textfiles

import java.io.IOException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class NewBufferedReaderWriterExample
{
    private final String fname;

    public NewBufferedReaderWriterExample(String fname) {
        this.fname = fname;
        System.out.println("constructor NewBufferedReaderWriter: this.fname = " + this.fname);
    }

    public void writeFile() throws IOException
    {
        Path path = Paths.get(fname);   // NB: Path ... = Paths

        Charset charset = Charset.forName("US-ASCII");  // optional

        BufferedWriter writer = Files.newBufferedWriter(path, charset);
        writer.write("");
        writer.write("This is a line number one.\n");
        writer.write("This is a line number two.\n");
        writer.write("This is a line number three.\n");
        writer.close();
    }

    public void readFile() throws IOException
    {
        Path path = Paths.get(fname);   // NB: Path ... = Paths

        Charset charset = Charset.forName("US-ASCII");  // optional

        /// //////////////////////////////////////////////////////////
        /// //
        /// // you don't have to try/catch the exception in the method
        /// // do that in the main
        /// //
        /// //////////////////////////////////////////////////////////
        ///
        /// // try-with-resources
        /// try (BufferedReader reader = Files.newBufferedReader(path, charset))
        /// {
        ///     String line = null;
        ///     while ((line = reader.readLine()) != null) {
        ///         System.out.println(line);
        ///     }
        /// } catch (IOException e) {
        ///     System.err.format("IOException: %s%n", e);
        /// }

        BufferedReader reader = Files.newBufferedReader(path, charset);
        String line = null;
        while ((line = reader.readLine()) != null) {
            System.out.println(line);
        }
        reader.close();
    }

    public static void main(String[] args)
    {
        String fname = NewBufferedReaderWriterExample.class.getName() + ".txt";
        if (args.length > 0) fname = args[0];

        NewBufferedReaderWriterExample newBufferedReaderWriterExample =
            new NewBufferedReaderWriterExample(fname);

        // newBufferedReaderWriterExample.readFile();

        // write a new file
        try {
            newBufferedReaderWriterExample.writeFile();
        }
        catch (IOException e) {
            System.err.format("IOException: %s%n", e);
        }

        // read the file
        try {
            newBufferedReaderWriterExample.readFile();
        }
        catch (IOException e) {
            System.err.format("IOException: %s%n", e);
        }
    }
}
