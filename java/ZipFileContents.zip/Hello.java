import java.util.Scanner;

public class Hello {

    public static void countdown(int n) {
        if (n==0) {
            System.out.println("Blastoff!");
        }
        else {
            System.out.println(n);
            countdown(n - 1);
        }
    }

    public static void countup(int n)
    {
        if (n==0) {
            System.out.println("Blastoff!");
        }
        else {
            countup(n - 1);
            System.out.println(n);
        }
    }

    public static void displayBinary(int value) {
        // For more background about binary numbers, see http://www.mathsisfun.com/binary-number-system.html
        if (value>0) {
            displayBinary(value / 2);
            System.out.print(value % 2);
        }
    }

    public static int fibonacci(int n) {
        if (n == 1 || n == 2) return 1;
        else return fibonacci(n-1) + fibonacci(n-2);
    }

    public static void main(String[] args)      // args is an array of String
    {
	System.out.println("Hello, World!");

        System.out.println("args.length = " + args.length);
        // for (String s: args)
        for (int i=0; i<args.length; ++i)
        {
	    System.out.println("arg #" + i + ": " + args[i]);
	}
	System.out.println("Done with command line arguments\n");

	String fruit1 = "Apple";
	String fruit2 = "Orange";
	System.out.println(fruit1.equals(fruit2));

	// int n = 9;
	int n = 10;
	int reminder = n % 3;
	System.out.printf("reminder = %d\n",reminder);

	String strNumber = "12";
	Scanner scanner = new Scanner(strNumber);

	// System.out.println(scanner);

	int number = scanner.nextInt();
	System.out.println("number = " + number);

	strNumber = "123";
	if (scanner.hasNextInt()) {
	    number = scanner.nextInt();
	    System.out.println("number = " + number);
	}
	else System.out.println("the strNumber does not contain an int");

        System.out.println("\ncountdown");
	countdown(3);

        System.out.println("\ncountup");
	countup(3);

	System.out.println("Binary for 23 is 10111");
	displayBinary(23);
	System.out.println();

	System.out.println("\n1 + 2 is");
	System.out.println(1+2);
	System.out.println("1 + 2 = " + 1+2);

        int nFibonacci = 6;
	System.out.println("\nFibonacci");
	System.out.println("Fibonacci number for " + nFibonacci + " is " + fibonacci(nFibonacci));       // NB: fibonacci(5) = 5

	System.out.println("\nfor loop");
	for (int i=0; i<3; ++i) {
	    System.out.println(i);
	}
    }
}
